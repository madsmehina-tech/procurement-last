# -*- coding: utf-8 -*-
"""The certificates page: every filter of the old page is still there, the chips keep their own counts, and the phone layer is wired."""
from datetime import datetime

import pytest

import conftest
import fake_db
import helpers as h


@pytest.fixture(autouse=True)
def _schema():
    conftest.build_schema()


@pytest.fixture()
def client():
    import app as appmod
    c = appmod.app.test_client()
    with c.session_transaction() as s:
        s["user_id"] = 1
    return c


def _world():
    a, b = h.add_sub("مقاول أ"), h.add_sub("مقاول ب")
    c1 = h.add_cert(a, 1000, no=1)                                              # مُدخَل
    c2 = h.add_cert(a, 2000, no=2, status="مصروف")
    fake_db.execute_insert("INSERT INTO [Payments] ([CertificateID], [Amount], [PaidAt]) VALUES (?, ?, ?)", (c2, 2000, datetime.now()))
    h.add_cert(b, 500, no=1, status="مرفوض")
    return a, b


def test_all_the_old_filters_are_still_on_the_page(client):
    _world()
    html = client.get("/certificates").get_data(as_text=True)
    for needle in ('name="q"', 'name="sub"', 'name="project"', 'name="date_from"', 'name="date_to"', 'name="status"', "تصدير Excel", "+ مستخلص جديد"):
        assert needle in html, needle


def test_every_status_chip_keeps_its_own_count_when_one_status_is_chosen(client):
    _world()
    html = client.get("/certificates?status=مصروف").get_data(as_text=True)
    import re
    chips = re.findall(r'<a class="chip[^"]*"[^>]*>.*?</a>', html, re.S)
    nums = {re.search(r'badge [a-z]+">([^<]+)<', c).group(1): int(re.search(r"<i>(\d+)</i>", c).group(1)) for c in chips if "badge" in c}
    assert nums["مُدخَل"] == 1 and nums["مصروف"] == 1 and nums["مرفوض"] == 1          # the old page showed 0 for the others once one status was chosen


def test_filtering_by_contractor_and_search_still_works(client):
    a, b = _world()
    html = client.get("/certificates?sub=%d" % b).get_data(as_text=True)
    body = html.split("<tbody>")[1]
    assert "مقاول ب" in body and "مقاول أ" not in body
    html = client.get("/certificates?q=مقاول أ").get_data(as_text=True)
    assert "مقاول أ" in html.split("<tbody>")[1]


def test_the_paid_bar_shows_the_percentage(client):
    _world()
    html = client.get("/certificates?status=مصروف").get_data(as_text=True)
    assert 'style="width:100%;"' in html and "100%" in html


def test_the_phone_layer_is_present_on_every_page(client):
    html = client.get("/certificates").get_data(as_text=True)
    assert 'class="tabbar' in html and "data-open-menu" in html
    js = open("static/ui.js", encoding="utf-8").read()
    assert "data-label" in js and "table.list" in js
    css = open("static/style.css", encoding="utf-8").read()
    assert "table.list.cards" in css and "font-family: 'Cairo'" in css and "fonts/cairo-arabic-400.woff2" in css
    import os
    assert os.path.exists("static/fonts/cairo-arabic-400.woff2") and os.path.exists("static/fonts/Cairo-OFL-License.txt")


def test_the_home_page_has_the_phone_quick_actions_and_the_filter_toggle_exists(client):
    home = client.get("/").get_data(as_text=True)
    assert 'class="quick no-print"' in home and "أمر صرف" in home and "بحث شامل" in home
    page = client.get("/certificates").get_data(as_text=True)
    assert 'data-toggle=".filters"' in page
    shown = client.get("/certificates?q=x").get_data(as_text=True)
    assert 'class="filters show"' in shown                                  # a search in progress keeps the filter bar open on a phone


def test_the_cycle_decision_page_keeps_its_fields_and_has_the_new_summary(client):
    import cycles_service as cy
    s = h.add_sub()
    h.add_cert(s, 5000, no=1)
    h.add_cert(s, 7000, no=2)
    cid = cy.create("اختبار", datetime.now(), "t")
    cy.to_decision_stage(cid, "t")
    html = client.get("/cycles/%d" % cid).get_data(as_text=True)
    for needle in ('id="decSum"', 'id="decChecks"', "ملخص القرار", "name=\"decision_", "name=\"partial_", "name=\"note_", 'name="intent" value="finalize"', 'name="intent" value="save"', "dsel"):
        assert needle in html, needle
    assert html.count('class="search-box dsel"') == 2                        # the real <select> stays in the form (the buttons only set it)


def test_close_cycle_needs_every_outcome_then_closes():
    import cycles_service as cy
    import fake_db
    import helpers as h
    from datetime import datetime
    s = h.add_sub("مقاول الإغلاق")
    a = h.add_cert(s, 100000, no=1)
    cid = h.cycle_to_execution({a: (cy.D_FULL, None)})
    with pytest.raises(cy.CycleError):
        cy.close_cycle(cid, "t")                         # no outcome yet -> refused, says why
    cy.set_group_execution(cid, s, cy.EX_DONE, datetime.now(), "R", "", "t")
    # simulate a cycle that was left open although every outcome exists
    fake_db.execute("UPDATE [PaymentCycles] SET [Status] = ? WHERE [CycleID] = ?", (cy.ST_APPROVED, cid))
    cy.close_cycle(cid, "t")
    assert fake_db.query("SELECT [Status] FROM [PaymentCycles] WHERE [CycleID] = ?", (cid,))[0]["Status"] == cy.ST_DONE


def test_new_order_page_keeps_every_field_and_has_the_three_steps():
    import re
    import app as appmod
    cl = appmod.app.test_client()
    with cl.session_transaction() as s:
        s["user_id"] = 1
    html = cl.get("/orders/new").get_data(as_text=True)
    for name in ("po_number", "order_date", "quote_no", "location", "supplier", "project", "receiver", "phone", "discount", "extra_notes", "hide_warehouse_note", "item_name", "item_unit", "item_qty", "item_price"):
        assert 'name="%s"' % name in html or "name=\"%s\"" % name in html, name
    assert "المورد والمشروع" in html and "المراجعة والإصدار" in html and "po-stepper" in html
    assert html.count('id="saveBtn"') == 1
