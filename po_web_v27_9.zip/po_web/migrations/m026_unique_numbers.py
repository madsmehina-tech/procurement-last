# -*- coding: utf-8 -*-
"""
m026_unique_numbers - the database itself refuses a duplicate purchase-order number, payment-cycle number or number-series row.

Until now the only protection was the application's write lock («read the last number, add one, insert»). That is enough while ONE server process
runs, but a second process (a forgotten console window, a tool run at the wrong moment) could create two orders with the same number. A unique index
makes the database refuse the second one whatever happens.

Safe by design: it first looks for duplicates ALREADY in the data. If it finds any it skips that index, prints exactly what to fix, and carries on -
it never fails the migration and never changes your data. Run it again after fixing the duplicates and the index is created.
(The contract number is deliberately not indexed: a contract may be saved without a number, and several «empty» numbers are legal.)
"""
import db

INDEXES = [
    ("PurchaseOrders", "ux_po_number", ["PONumber"], "رقم أمر الشراء"),
    ("PaymentCycles", "ux_cycle_no", ["CycleNo"], "رقم دورة الصرف"),
    ("NumberSeries", "ux_number_series", ["SeriesKey", "SeriesYear"], "سلسلة ترقيم العقود"),
]


def _duplicates(table, cols):
    cl = ", ".join("[%s]" % c for c in cols)
    return db.query("SELECT %s, COUNT(*) AS N FROM [%s] GROUP BY %s HAVING COUNT(*) > 1" % (cl, table, cl))


def missing():
    """[(table, index name, label)] of the unique indexes that should exist and do not (tables that do not exist are ignored)."""
    return [(t, n, label) for t, n, _c, label in INDEXES if db.table_exists(t) and not db.index_exists(t, n)]


def main():
    """Returns True when every index exists, False when at least one could not be created (duplicates / error):
    the runner then does NOT record the migration as applied, so it is retried by the next `python migrate.py`."""
    complete = True
    for table, name, cols, label in INDEXES:
        if not db.table_exists(table):
            print("- %s: table not found, skipped" % table)
            continue
        if db.index_exists(table, name):                 # already there (language-independent check): nothing to do
            print("- %s.%s: already exists" % (table, ", ".join(cols)))
            continue
        dups = _duplicates(table, cols)
        if dups:
            shown = "؛ ".join(" / ".join(str(d[c]) for c in cols) + " (×%d)" % d["N"] for d in dups[:10])
            print("!! %s: يوجد تكرار في %s فلم يُنشأ الفهرس: %s" % (table, label, shown))
            print("   صحّح التكرار ثم أعد تشغيل:  python migrate.py")
            complete = False
            continue
        try:
            db.execute("CREATE UNIQUE INDEX [%s] ON [%s] (%s)" % (name, table, ", ".join("[%s]" % c for c in cols)))
            print("- %s.%s: unique index created" % (table, ", ".join(cols)))
        except Exception as e:                           # noqa - an index that already exists is fine; any other problem is reported, never fatal
            msg = " ".join(str(e).split())[:140]
            # the REAL Access driver says «Table 'X' already has an index named 'Y'» (found on a real Windows run); other languages say it differently,
            # so the wording is only a hint: the catalogue is asked again after the failure
            exists = any(k in msg.lower() for k in ("already exists", "already has an index")) or "موجود" in msg or db.index_exists(table, name)
            print("- %s.%s: %s" % (table, ", ".join(cols), "already exists" if exists else "skipped (%s)" % msg))
            if not exists:
                complete = False
    return complete
